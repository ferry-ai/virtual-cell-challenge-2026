"""Small launcher and readout contract tests; no model, real data or network."""
import hashlib
import io
from pathlib import Path
import tarfile
import tempfile
import unittest

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp

import score_stack_pilot as score
import stack_remote_runner as remote


def archive_bytes(entries):
    b = io.BytesIO()
    with tarfile.open(fileobj=b, mode="w:gz") as t:
        for name, contents in entries:
            info = tarfile.TarInfo(name)
            info.size = len(contents)
            t.addfile(info, io.BytesIO(contents))
    return b.getvalue()


class RemoteTest(unittest.TestCase):
    def test_extract_exact_rejects_extra_duplicate_and_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp) / "safe"
            remote.extract_exact(archive_bytes([("./a.txt", b"ok")]), dest,
                                 {"a.txt": hashlib.sha256(b"ok").hexdigest()})
            self.assertEqual((dest / "a.txt").read_bytes(), b"ok")
            for entries, expected in [([("extra", b"x")], {"a.txt": None}),
                ([("same", b"x"), ("same", b"x")], {"same": None}),
                ([("../escape", b"x")], {"../escape": None})]:
                with self.assertRaises(ValueError):
                    remote.extract_exact(archive_bytes(entries), Path(tmp) / "other", expected)

    def test_projection_sign_and_exact_null(self):
        targets = [f"T{i}" for i in range(12)]
        base = pd.DataFrame(.2, index=targets, columns=score.FIVE)
        anchor = {m: {"baseline": 0., "replicate": 1.} for m in score.FIVE}
        anchor["de_wilcoxon_lfc_nmae"] = {"baseline": 1., "replicate": 0.}
        null = score.contrast(base, base, anchor)
        self.assertEqual(null["delta_projection"], 0)
        self.assertFalse(null["proceed_to_distinct_confirmation"])
        candidate = base.copy()
        candidate["pds_cosine"] += .06
        candidate["de_wilcoxon_lfc_nmae"] -= .12
        changed = score.contrast(candidate, base, anchor)
        self.assertAlmostEqual(changed["delta_projection"], .03)
        self.assertTrue(changed["proceed_to_distinct_confirmation"])
        candidate["pds_cosine"] = .1
        self.assertFalse(score.contrast(candidate, base, anchor)["proceed_to_distinct_confirmation"])

    def test_eligibility_change_is_not_ignored(self):
        base = pd.DataFrame(.2, index=range(12), columns=score.FIVE)
        candidate = base.copy()
        candidate.iloc[0, 0] = np.nan
        anchors = {m: {"baseline": 0., "replicate": 1.} for m in score.FIVE}
        with self.assertRaises(ValueError):
            score.contrast(candidate, base, anchors)

    def test_prediction_contract_requires_all_400_cells(self):
        genes = ["a", "b"]
        obj = ad.AnnData(sp.csr_matrix(np.ones((800, 2), dtype=np.float32)),
            obs=pd.DataFrame({"gene": ["T1"] * 400 + ["T2"] * 400}, index=[str(i) for i in range(800)]),
            var=pd.DataFrame(index=genes))
        x, labels = score.validate_prediction(obj, ["T1", "T2"], genes)
        self.assertEqual(x.shape, (800, 2))
        with self.assertRaises(ValueError):
            score.validate_prediction(obj[:-1].copy(), ["T1", "T2"], genes)
        with self.assertRaises(ValueError):
            score.validate_prediction(obj, ["T1", "T2"], genes[::-1])


if __name__ == "__main__":
    unittest.main()

"""Stage 98: panel effects from every same-target source, and how they predict one another.

Sources, all put on the official axis by `vcc2026.multisource.AxisTable`:

* ``k562``: the K562 genome-wide bulk (Replogle 2022), `effects_from_bulk`, as stage 76;
  its per-gene shrinkage is replaced by `z_shrink`, the one every source gets here;
* ``cd4_Rest``, ``cd4_Stim8hr``, ``cd4_Stim48hr``: the CD4 pseudobulk rows of stage 97,
  one fold change per donor against that donor's controls, averaged over donors;
* ``cd4_halfA`` / ``cd4_halfB``: CD4 Stim48hr split by donors (two against two), used only
  as a replicate ceiling for the CD4 comparisons.

Transfer reports (`transfer_report`, effect-space proxies, not scores): each source
predicting each other one on the panel targets both measured, panel genes excluded, with
the source's own mean response removed at gamma 0, 0.5 and 1. The question they answer is
"how much of a target's response in one cell type is visible in another", for THESE 300
targets -- the only regime the official panel can be scored in.

Outputs: one npz per source on the official axis under ``--cache`` (data root, D-001) and
``transfer.json`` / ``coverage.json`` in ``--report-dir``. Nothing is overwritten.

The panel is ``--targets-csv`` read by `vcc2026.panel.read_panel` (the ``target_gene`` column by
name; defect D2 of the dress rehearsal, reports/invii/prova_generale_2026-09-28/). Once every npz
is saved, and before the transfer reports, the cache gets a ``manifest.json``
(`vcc2026.panel.write_cache_manifest`): ``targets_sha256``, the panel it was built for, which
stage 100 checks against the panel it reads (defect D4); the targets file; the argv and inputs;
and per source its targets, the panel targets it lacks, and its npz's size and sha256. The npz
files are written as before.

``--pseudo-scale`` is passed to `effects_from_pseudobulk` for the CD4 and extra sources. The
default, "constant", is how every cache up to r5 was built; "library" keeps the pseudocount in the
smaller group and gives the larger the same fraction of its total, so a gene with no count in
either group gets 0 instead of the ratio of the totals (reports/sorgenti/pseudoconteggio_2026-09-27/).
``--min-expected`` instead drops, gene by gene, a donor whose controls predict fewer than that many
counts in the target group, whatever the target's own count. K562 goes through `effects_from_bulk` either way.

    python scripts/98_multisource_effects.py --cd4-rows <stage-97 h5ad> \
        --cache <data_root>/processed/multisource_2026-09-22 --report-dir reports/sorgenti/multisource_2026-09-22
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import anndata as ad
import h5py
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from vcc2026 import config  # noqa: E402
from vcc2026.bench import log  # noqa: E402
from vcc2026.genes import official_axis  # noqa: E402
from vcc2026.manifest import file_fingerprint  # noqa: E402
from vcc2026.multisource import (  # noqa: E402
    AxisTable, effects_from_pseudobulk, mix, shared_signal, transfer_report, z_shrink,
)
from vcc2026.panel import read_panel, write_cache_manifest  # noqa: E402
from vcc2026.predictor_sc import effects_from_bulk  # noqa: E402
from vcc2026.resources import peak_rss_bytes  # noqa: E402
from vcc2026.sc_stream import read_frame  # noqa: E402

DATA_ROOT = config.paths().data_root  # VCC2026_DATA_ROOT, else configs/config.yaml


def k562_table(path: Path, targets: list[str], axis) -> AxisTable:
    with h5py.File(path, "r") as f:
        labels = np.array([s.decode() for s in f["obs/gene_transcript"][:]])
        is_ntc = np.array(["non-targeting" in lab for lab in labels])
        symbols = np.array(["non-targeting" if nt else lab.split("_")[1] for lab, nt in zip(labels, is_ntc)])
        rows = np.flatnonzero(is_ntc | np.isin(symbols, targets))
        means = f["X"][rows]
        n_cells = f["obs/num_cells_filtered"][:][rows]
        names = read_frame(f["var"])["gene_name"].astype(str).to_numpy()
    src = effects_from_bulk(means, n_cells, symbols[rows], is_ntc[rows], names, targets=targets)
    # the same local shrinkage as every other source, in place of the single-normal prior
    src.shrunk = z_shrink(src.raw, src.se).astype(np.float32)
    return AxisTable.from_source("k562", src, axis)


def save_table(tab: AxisTable, cache: Path) -> Path:
    path = cache / f"{tab.name}.npz"
    if path.exists():
        raise FileExistsError(path)
    np.savez_compressed(path, targets=np.array(tab.targets), shrunk=tab.shrunk, raw=tab.raw, se=tab.se,
                        n_cells=tab.n_cells, meta=json.dumps(tab.meta, default=str))
    return path


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--k562-bulk", type=Path, default=DATA_ROOT / "external/K562_gwps_raw_bulk_01.h5ad")
    p.add_argument("--cd4-rows", type=Path, required=True)
    p.add_argument("--targets-csv", type=Path, default=DATA_ROOT / "raw/controls/pert_counts.csv")
    p.add_argument("--cache", type=Path, required=True)
    p.add_argument("--report-dir", type=Path, required=True)
    p.add_argument("--gammas", type=float, nargs="+", default=[0.0, 0.5, 1.0])
    p.add_argument("--extra", action="append", default=[], metavar="NAME=PATH",
                   help="another pseudobulk h5ad with obs target/donor/condition/n_cells (e.g. stage 102's "
                        "Orion rows, where donor = GEM batch); all its rows form one source NAME")
    p.add_argument("--pseudo-scale", choices=["constant", "library"], default="constant",
                   help="pseudocounts of the pseudobulk sources (see the docstring)")
    p.add_argument("--min-expected", type=float, default=0.0,
                   help="drop a donor for a gene when its controls predict fewer counts than this in the target group (0: never)")
    args = p.parse_args()
    started = datetime.now(timezone.utc).isoformat()
    for path in (args.report_dir / "transfer.json", args.cache):
        if path.exists():
            raise FileExistsError(f"{path} exists; new runs go to a new destination")
    panel = read_panel(args.targets_csv)          # refused here, before anything is written
    args.cache.mkdir(parents=True)
    args.report_dir.mkdir(parents=True, exist_ok=True)
    axis = np.asarray(official_axis().symbols)
    panel_cols = np.flatnonzero(np.isin(axis, panel))

    tables: dict[str, AxisTable] = {}
    log("K562 bulk effects for the panel")
    tables["k562"] = k562_table(args.k562_bulk, panel, axis)
    log(f"reading CD4 rows {args.cd4_rows}")
    cd4 = ad.read_h5ad(args.cd4_rows)
    obs = cd4.obs[["target", "donor", "condition", "n_cells"]].copy()
    for cond in sorted(obs["condition"].unique()):
        src = effects_from_pseudobulk(cd4.X, obs, cd4.var_names, targets=panel, condition=cond,
                                      pseudo_scale=args.pseudo_scale, min_expected=args.min_expected)
        tables[f"cd4_{cond}"] = AxisTable.from_source(f"cd4_{cond}", src, axis)
        log(f"  cd4 {cond}: {len(src.targets)} targets")
    donors = sorted(obs["donor"].unique())
    halves = {"cd4_halfA": donors[: len(donors) // 2], "cd4_halfB": donors[len(donors) // 2:]}
    for name, ds in halves.items():
        m = obs["donor"].isin(ds).to_numpy()
        src = effects_from_pseudobulk(cd4.X[m], obs[m], cd4.var_names, targets=panel, condition="Stim48hr",
                                      pseudo_scale=args.pseudo_scale, min_expected=args.min_expected)
        tables[name] = AxisTable.from_source(name, src, axis)
    del cd4
    # The three culture conditions as one CD4 source: reliability-weighted mean, gamma 0.
    conds = [n for n in tables if n.startswith("cd4_") and not n.startswith("cd4_half")]
    eff, w = mix([tables[n] for n in conds], panel, gamma=0.0)
    have = (w > 0).any(axis=1)
    cells = np.array([sum(tables[n].n_cells[tables[n].index()[t]] for n in conds if t in tables[n].index())
                      for t in panel])
    mixed = np.where(w > 0, eff, np.nan).astype(np.float32)[have]
    # the same weighted mean of the conditions' RAW effects, so recipes can use either scale
    raw_tabs = [AxisTable(n, tables[n].targets, tables[n].raw, tables[n].raw, tables[n].se, tables[n].n_cells)
                for n in conds]
    eff_raw, w_raw = mix(raw_tabs, panel, gamma=0.0)
    mixed_raw = np.where(w_raw > 0, eff_raw, np.nan).astype(np.float32)[have]
    tables["cd4_mix"] = AxisTable("cd4_mix", [t for t, h in zip(panel, have) if h], mixed, mixed_raw,
                                  np.full_like(mixed, np.nan), cells[have],
                                  {"from": conds, "how": "reliability-weighted mean of the conditions, gamma 0; "
                                                         "shrunk and raw mixed separately"})

    for spec in args.extra:
        name, _, path = spec.partition("=")
        log(f"reading extra source {name} from {path}")
        extra = ad.read_h5ad(path)
        eobs = extra.obs[["target", "donor", "condition", "n_cells"]].copy()
        src = effects_from_pseudobulk(extra.X, eobs, extra.var_names, targets=panel, condition=None,
                                      pseudo_scale=args.pseudo_scale, min_expected=args.min_expected)
        tables[name] = AxisTable.from_source(name, src, axis)
        log(f"  {name}: {len(src.targets)} targets")
        del extra

    coverage = {}
    for name, tab in tables.items():
        save_table(tab, args.cache)
        measured = np.isfinite(tab.shrunk).any(axis=0)
        coverage[name] = {"targets": len(tab.targets), "genes_on_axis": int(measured.sum()),
                          "median_cells": float(np.median(tab.n_cells)) if len(tab.n_cells) else 0,
                          "meta": tab.meta}
    # the cache is complete: say which panel it was built for before the reports, which can take hours
    write_cache_manifest(
        args.cache, "98_multisource_effects", args.targets_csv, panel,
        {name: {"targets": c["targets"], "genes_on_axis": c["genes_on_axis"], "median_cells": c["median_cells"],
                "panel_targets_missing": [t for t in panel if t not in set(tables[name].targets)]}
         for name, c in coverage.items()},
        started_utc=started, report_dir=str(args.report_dir), pseudo_scale=args.pseudo_scale,
        min_expected=args.min_expected,
        inputs={"k562_bulk": file_fingerprint(args.k562_bulk), "cd4_rows": file_fingerprint(args.cd4_rows),
                "extra": {e.partition("=")[0]: file_fingerprint(e.partition("=")[2]) for e in args.extra}},
        peak_rss_bytes_before_reports=peak_rss_bytes())
    log(f"wrote {args.cache / 'manifest.json'}")
    commons = {n: t.common() for n, t in tables.items()}
    common_corr = {}
    names = list(tables)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            ok = np.isfinite(tables[a].shrunk).any(0) & np.isfinite(tables[b].shrunk).any(0)
            ok[panel_cols] = False
            if ok.sum() > 50:
                common_corr[f"{a}~{b}"] = float(np.corrcoef(commons[a][ok], commons[b][ok])[0, 1])

    shared = {}
    shared_pairs = [("k562", "cd4_mix"), ("k562", "cd4_Rest"), ("k562", "cd4_Stim8hr"), ("k562", "cd4_Stim48hr"),
                    ("cd4_Rest", "cd4_Stim48hr"), ("cd4_halfA", "cd4_halfB")]
    shared_pairs += [(a, e.partition("=")[0]) for e in args.extra for a in ("k562", "cd4_mix")]
    for a, b in shared_pairs:
        for g in args.gammas:
            shared[f"{a}~{b}|gamma={g}"] = shared_signal(tables[a], tables[b], panel, exclude_cols=panel_cols, gamma=g)
            s = shared[f"{a}~{b}|gamma={g}"]
            log(f"  shared {a}~{b} g={g}: corr {s['corr']:.3f}, w_{a} {s['weight_a']:.2f}, amp {s['amplitude']:.3f}")

    # cd4_mix is only ever a predictor, and only of K562: it contains every CD4 condition.
    pairs = [(a, b) for a in names for b in names
             if a != b and b != "cd4_mix" and (a != "cd4_mix" or b == "k562")
             and not (a.startswith("cd4_half") ^ b.startswith("cd4_half"))]
    reports = []
    for a, b in pairs:
        for g in args.gammas:
            pred, w = mix([tables[a]], panel, gamma=g)
            rep = transfer_report(pred, w, tables[b], panel, exclude_cols=panel_cols)
            reports.append({"from": a, "to": b, "gamma": g, **rep})
            log(f"  {a:>12} -> {b:<12} g={g:.1f} r={rep['median']['pearson']:.3f} "
                f"rc={rep['median']['pearson_centred']:.3f} top10={rep['median']['purity_top10']:.3f} "
                f"reach~{rep['median']['reach_proxy']:.3f} pds~{rep['pds_proxy_mean']:.3f} "
                f"a*={rep['amplitude_star']:.3f} skill={rep['skill_at_amplitude_star']:.3f}")
    stamp = datetime.now(timezone.utc).isoformat()
    (args.report_dir / "coverage.json").write_text(json.dumps(
        {"stage": "98_multisource_effects", "written_utc": stamp, "sources": coverage,
         "common_response_correlation": common_corr, "shared_signal": shared,
         "cache": str(args.cache), "pseudo_scale": args.pseudo_scale,
         "min_expected": args.min_expected}, indent=2, default=str),
        encoding="utf-8")
    with open(args.report_dir / "transfer.json", "x", encoding="utf-8") as fh:
        json.dump({"stage": "98_multisource_effects", "written_utc": stamp,
                   "claim_type": "measurement in effect space (pseudobulk ln fold changes); proxies, not VCC scores",
                   "panel_genes_excluded": int(panel_cols.size), "reports": reports}, fh, indent=2)
    log(f"wrote {args.report_dir}")


if __name__ == "__main__":
    main()
